package pruebas;

import herramientas.encriptacion.Encriptacion;

public class PruebaEncriptacion {


    public static void main(String[] args) {
        Encriptacion.encriptarArchivo("estructuras/src/texto.txt");

    }
}
