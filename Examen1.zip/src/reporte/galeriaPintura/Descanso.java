package reporte.galeriaPintura;

public class Descanso {

    @Override
    public String toString() {
        return "Esta descanzando.";
    }
}
