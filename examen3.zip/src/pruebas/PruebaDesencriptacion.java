package pruebas;

public class PruebaDesencriptacion {
    public static void main(String[] args) {

        //Desencriptacion.desencriptar("estructuras/src/textoEncriptado.txt");
    }
}
