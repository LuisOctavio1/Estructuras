package pruebas;

import menus.MenuValidaciones;

/**
 * Prueba de la validacion de archivos y expresiones
 */
public class PruebaValidacion {
    public static void main(String[] args) {
        MenuValidaciones.manejarMenu();
    }
}
