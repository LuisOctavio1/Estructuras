package practica1.trabajadores;

public class AlbanilMaestro extends Trabajador {
    /*
    Esta clase tiene los atributos extra que un albañil maestro debe de tener.
     */
    private int aniosExperiencia;
    public AlbanilMaestro(String nombre, String ciudadResidencia, int sueldo,int aniosExperiencia) {
        super(nombre, ciudadResidencia, sueldo);
        this.aniosExperiencia = aniosExperiencia;
    }
    public String toString() {
        return ("Nombre: " + getNombre()+ ", ciudad: " + getCiudadResidencia()+ ", sueldo: " + getSueldo());
    }
}
