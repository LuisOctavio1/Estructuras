package practica1.trabajadores;

public class Albanil extends Trabajador {
    /*
    Esta clase tiene los atributos extra que un albañil debe de tener.
     */
    public Albanil(String nombre, String ciudadResidencia, int sueldo) {
        super(nombre, ciudadResidencia, sueldo);
    }

    public String toString() {
        return ("Nombre: " + getNombre()+ ", ciudad: " + getCiudadResidencia()+ ", sueldo: " + getSueldo());
    }
}
