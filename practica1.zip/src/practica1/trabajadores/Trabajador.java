package practica1.trabajadores;

public class Trabajador {
    /*
    Esta clase contiene la informacion que todo trabajador debera tener.
     */
    private String nombre;
    private String ciudadResidencia;
    private int sueldo;
    private boolean activo;

    public Trabajador(String nombre, String ciudadResidencia, int sueldo){
        this.nombre = nombre;
        this.ciudadResidencia = ciudadResidencia;
        this.sueldo = sueldo;
        this.activo = false;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCiudadResidencia() {
        return ciudadResidencia;
    }

    public void setCiudadResidencia(String ciudadResidencia) {
        this.ciudadResidencia = ciudadResidencia;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

}
