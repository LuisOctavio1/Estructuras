package practica1.trabajadores;

public class IngenieroCivil extends Trabajador {
    /*
    Esta clase tiene los atributos extra que un ingeniero civil debe de tener.
     */
    private int aniosExperiencia;
    private String especialidad;
    public IngenieroCivil(String nombre, String ciudadResidencia, int sueldo, int aniosExperiencia, String especialidad) {
        super(nombre, ciudadResidencia, sueldo);
        this.aniosExperiencia = aniosExperiencia;
        this.especialidad = especialidad;
    }
    public String toString() {
        return ("Nombre: " + getNombre()+ ", ciudad: " + getCiudadResidencia()+ ", sueldo: " + getSueldo());
    }
}
