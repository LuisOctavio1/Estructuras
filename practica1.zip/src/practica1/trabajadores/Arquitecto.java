package practica1.trabajadores;

public class Arquitecto extends Trabajador {
    /*
    Esta clase tiene los atributos extra que un arquitecto debe de tener.
     */
    private int aniosExperiencia;
    public Arquitecto(String nombre, String ciudadResidencia, int sueldo,int aniosExperiencia) {
        super(nombre, ciudadResidencia, sueldo);
        this.aniosExperiencia = aniosExperiencia;
    }
    public String toString() {
        return ("Nombre: " + getNombre()+ ", ciudad: " + getCiudadResidencia()+ ", sueldo: " + getSueldo());
    }
}
