package practica1.registrosConsultas;
import practica1.construccion.Construccion;
import practica1.construccion.Materiales;
import practica1.construccion.Supervisor;
import practica1.trabajadores.*;

import java.util.ArrayList;
import java.util.Scanner;
/*
En esta clase estaran todos los metodos necesarios para generar los registros.
 */

public class RegistrosYAltas {
    public Scanner sc = new Scanner(System.in);
    private static ArrayList<Albanil> albaniles = new ArrayList<>();
    private static ArrayList<AlbanilMaestro> albanilesMaestro = new ArrayList<>();
    private static ArrayList<Arquitecto> arquitectos = new ArrayList<>();
    private static ArrayList<IngenieroCivil> ingenieroCivils = new ArrayList<>();
    private static ArrayList<Materiales> materiales = new ArrayList<>();
    private static ArrayList<Supervisor> supervisors = new ArrayList<>();
    private static ArrayList<Construccion> construccions = new ArrayList<>();
    private static ArrayList<Trabajador> trabajadors = new ArrayList<>();

    public Trabajador registrarTrabajador(){
        System.out.println("Ingresa el nombre del trabajador");
        String nombre = sc.next();
        System.out.println("Ingresa la ciudad donde reside");
        String ciudad = sc.next();
        System.out.println("Ingresa el suledo");
        int sueldo = sc.nextInt();
        Trabajador trabajador = new Trabajador(nombre,ciudad,sueldo);
        return trabajador;
    }

    public void registrarAlbanil(){
        Trabajador trabajador = registrarTrabajador();
        Albanil albanil = new Albanil(trabajador.getNombre(),trabajador.getCiudadResidencia(),trabajador.getSueldo());
        albaniles.add(albanil);
        trabajadors.add(albanil);
    }

    public void registraAlbanilMaestro(){
        Trabajador trabajador = registrarTrabajador();
        System.out.println("Ingresa los años de experiencia");
        int anios = sc.nextInt();
        AlbanilMaestro albanil = new AlbanilMaestro(trabajador.getNombre(),trabajador.getCiudadResidencia(),trabajador.getSueldo(),anios);
        albanilesMaestro.add(albanil);
        trabajadors.add(albanil);
    }

    public void registrarArquitecto(){
        Trabajador trabajador = registrarTrabajador();
        System.out.println("Ingresa los años de experiencia");
        int anios = sc.nextInt();
        Arquitecto arquitecto = new Arquitecto(trabajador.getNombre(),trabajador.getCiudadResidencia(),trabajador.getSueldo(),anios);
        arquitectos.add(arquitecto);
        trabajadors.add(arquitecto);
    }

    public void registrarIngCivil(){
        Trabajador trabajador = registrarTrabajador();
        System.out.println("Ingresa los años de experiencia");
        int anios = sc.nextInt();
        System.out.println("Ingresa la especialidad(ninguna en caso de no tener)");
        String especialidad = sc.next();
        IngenieroCivil ingenieroCivil = new IngenieroCivil(trabajador.getNombre(),trabajador.getCiudadResidencia(),trabajador.getSueldo(),anios,especialidad);
        ingenieroCivils.add(ingenieroCivil);
        trabajadors.add(ingenieroCivil);
    }

    public void registrarMateriales(){
        System.out.println("Escribe el nombre del material");
        String nombre = sc.next();
        System.out.println("Escribe el precio");
        int precio = sc.nextInt();
        System.out.println("Escribe la cantidad disponible");
        int cantidad = sc.nextInt();

        Materiales material = new Materiales(nombre,precio,cantidad);
        materiales.add(material);
    }

    public void registrarSupervisor(){
        System.out.println("Escribe el nombre");
        String nombre = sc.next();
        System.out.println("Escribe la escolaridad");
        String escolaridad = sc.next();
        System.out.println("Escribe las años de experiencia");
        int aniosExperiencia = sc.nextInt();
        Supervisor supervisor = new Supervisor(nombre,escolaridad,aniosExperiencia);
        supervisors.add(supervisor);
    }

    /*
    Este metodo sirve para elegir un supervisor de una lista de estos para la creacion de objetos construcciones.
     */
    public int elegirSupervisor(){
        int indice = 1;
        System.out.println("Elige un supervisor(ingresa el indice del supervisor que desees)");
        for (Supervisor supervisor:
                supervisors) {
            System.out.println(indice + ". " + supervisor);
            indice++;
        }
        int eleccion = sc.nextInt();
        return eleccion;
    }
    /*
    Este metodo es para elegir construccionesal momento de querer agregarle trabajadores.
     */

    public int elegirConstruccion(){
        int indice =1;
        System.out.println("Elige una construccion(ingresa el indice de la construccion que desees)");
        for (Construccion construccion:
                construccions) {
            System.out.println(indice + ". " + construccion);
            indice++;
        }
        int eleccion = sc.nextInt();
        return eleccion-1;

    }

    /*
    Este metodo es para elegir un trabajador de una lista para ponerlo en una construccion.
     */

    public int elegirTrabajador(){
        int indice =1;
        System.out.println("Elige el trabajador con el indice del que desees)");
        for (Trabajador trabajador:
                trabajadors) {
            System.out.println(indice + ". " + trabajador);
            indice++;
        }
        int eleccion = sc.nextInt();
        return eleccion-1;

    }

    public void registrarConstruccion(){
        System.out.println("Escribe el nombre de la ciudad donde se construira");
        String ciudad = sc.nextLine();
        System.out.println("Escribe el tipo de construccion (edificios,casas habitación etc))");
        String tipo = sc.nextLine();
        System.out.println("Escribe el presupuesto para la construcción");
        int presupuesto = sc.nextInt();
        int eleccion = elegirSupervisor();
        Supervisor supervisor = supervisors.get(eleccion-1);
        Construccion construccion = new Construccion(ciudad,tipo,presupuesto,supervisor);
        construccions.add(construccion);
    }

    public static ArrayList<Albanil> getAlbaniles() {
        return albaniles;
    }

    public static ArrayList<AlbanilMaestro> getAlbanilesMaestro() {
        return albanilesMaestro;
    }

    public static ArrayList<Arquitecto> getArquitectos() {
        return arquitectos;
    }

    public static ArrayList<IngenieroCivil> getIngenieroCivils() {
        return ingenieroCivils;
    }

    public static ArrayList<Materiales> getMateriales() {
        return materiales;
    }

    public static ArrayList<Supervisor> getSupervisors() {
        return supervisors;
    }

    public static ArrayList<Construccion> getConstruccions() {
        return construccions;
    }

    public static void setAlbaniles(ArrayList<Albanil> albaniles) {
        RegistrosYAltas.albaniles = albaniles;
    }

    public static void setAlbanilesMaestro(ArrayList<AlbanilMaestro> albanilesMaestro) {
        RegistrosYAltas.albanilesMaestro = albanilesMaestro;
    }

    public static void setArquitectos(ArrayList<Arquitecto> arquitectos) {
        RegistrosYAltas.arquitectos = arquitectos;
    }

    public static void setIngenieroCivils(ArrayList<IngenieroCivil> ingenieroCivils) {
        RegistrosYAltas.ingenieroCivils = ingenieroCivils;
    }

    public static void setMateriales(ArrayList<Materiales> materiales) {
        RegistrosYAltas.materiales = materiales;
    }

    public static void setSupervisors(ArrayList<Supervisor> supervisors) {
        RegistrosYAltas.supervisors = supervisors;
    }

    public static void setConstruccions(ArrayList<Construccion> construccions) {
        RegistrosYAltas.construccions = construccions;
    }

    public static ArrayList<Trabajador> getTrabajadors() {
        return trabajadors;
    }

    public static void setTrabajadors(ArrayList<Trabajador> trabajadors) {
        RegistrosYAltas.trabajadors = trabajadors;
    }
}
