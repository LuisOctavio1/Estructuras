package practica1.registrosConsultas;

import practica1.construccion.Construccion;
import practica1.construccion.Materiales;
import practica1.construccion.Supervisor;
import practica1.trabajadores.Albanil;
import practica1.trabajadores.AlbanilMaestro;
import practica1.trabajadores.Arquitecto;
import practica1.trabajadores.IngenieroCivil;

import java.util.ArrayList;
/*
En esta clase estaran todos los metodos para generar consultas.
 */

public class Consultas {
    public void consultarAlbanil(){
        ArrayList<Albanil> albaniles = RegistrosYAltas.getAlbaniles();
        System.out.println("Los albañiles son:");
        for (Albanil albanil:
             albaniles) {
            System.out.println(albanil);
        }
    }

    public  void  consultarAlbanilMaestro(){
        ArrayList<AlbanilMaestro> albanilMaestros = RegistrosYAltas.getAlbanilesMaestro();
        System.out.println("Los albañiles maestros son:");
        for (AlbanilMaestro albanil:
             albanilMaestros) {
            System.out.println(albanil);

        }
    }

    public void consultarArquitecto(){
        ArrayList<Arquitecto> arquitectos= RegistrosYAltas.getArquitectos();
        System.out.println("Los arquitectos son:");
        for (Arquitecto arquitecto:
             arquitectos) {
            System.out.println(arquitecto);
        }
    }

    public void consultarIngenieros(){
        ArrayList<IngenieroCivil>ingenieroCivils = RegistrosYAltas.getIngenieroCivils();
        System.out.println("Los ingenieros civiles son:");
        for (IngenieroCivil ingeniero:
             ingenieroCivils) {
            System.out.println(ingeniero);

        }
    }
    public void consultarMateriales(){
        ArrayList<Materiales> materiales = RegistrosYAltas.getMateriales();
        System.out.println("Los materiales son:");
        for (Materiales material:
             materiales) {
            System.out.println(material);

        }
    }

    public void consultarSupervisores(){
        ArrayList<Supervisor> supervisors= RegistrosYAltas.getSupervisors();
        System.out.println("Los supervisores son: ");
        for (Supervisor supervisor:
            supervisors ) {
            System.out.println(supervisor);
        }
    }

    public void consultarConstruccionesPendientes(){
        ArrayList<Construccion> construccions = RegistrosYAltas.getConstruccions();
        System.out.println("Las construcciones pendientes son: ");
        for (Construccion construccion:
             construccions) {
            if (!construccion.isEstado()){
                System.out.println(construccion);
            }

        }
    }
}
