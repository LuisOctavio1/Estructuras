package practica1.construccion;
/*
Esta clase tiene todo lo que debe de tener un supervsor.
 */

public class Supervisor {
    private String nombre;
    private String escolaridad;
    private int aniosExperiencia;

    public Supervisor(String nombre, String escolaridad, int aniosExperiencia) {
        this.nombre = nombre;
        this.escolaridad = escolaridad;
        this.aniosExperiencia = aniosExperiencia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEscolaridad() {
        return escolaridad;
    }

    public void setEscolaridad(String escolaridad) {
        this.escolaridad = escolaridad;
    }

    public int getAniosExperiencia() {
        return aniosExperiencia;
    }

    public void setAniosExperiencia(int aniosExperiencia) {
        this.aniosExperiencia = aniosExperiencia;
    }

    @Override
    public String toString() {
        return "Supervisor{" +
                "nombre='" + nombre + '\'' +
                ", escolaridad='" + escolaridad + '\'' +
                ", aniosExperiencia=" + aniosExperiencia +
                '}';
    }
}
