package practica1.construccion;

import practica1.trabajadores.Trabajador;

import java.util.ArrayList;
/*
Esta clase tiene todos los atributos que deberia tener una construccion.
 */
public class Construccion {
    private String ciudad;
    private String tipo;
    private int presupuesto;
    private ArrayList<Trabajador> trabajadores = new ArrayList<Trabajador>();
    private boolean estado;
    private Supervisor supervisor;

    public Construccion(String ciudad, String tipo, int presupuesto,Supervisor supervisor) {
        this.ciudad = ciudad;
        this.tipo = tipo;
        this.presupuesto = presupuesto;
        estado = false;
        this.supervisor = supervisor;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(int presupuesto) {
        this.presupuesto = presupuesto;
    }

    public ArrayList<Trabajador> getTrabajadores() {
        return trabajadores;
    }
    /*
    Este metodo sirve para agregar un trabajador, primero confirmando que este no esta en ninguna construccion ya.
     */
    public void agregarTrabajador(Trabajador trabajador){
        if (!trabajador.isActivo()){
            trabajador.setActivo(true);
            trabajadores.add(trabajador);
        }else{
            System.out.println("Este trabajador ya esta en una construcción");
        }

    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Construccion{" +
                "ciudad='" + ciudad + '\'' +
                ", tipo='" + tipo + '\'' +
                ", presupuesto=" + presupuesto +
                ", trabajadores=" + trabajadores +
                ", estado=" + estado +
                ", supervisor=" + supervisor +
                '}';
    }
}
