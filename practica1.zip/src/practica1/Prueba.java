package practica1;

import practica1.construccion.Construccion;
import practica1.registrosConsultas.Consultas;
import practica1.registrosConsultas.RegistrosYAltas;
import practica1.trabajadores.Trabajador;

import java.util.ArrayList;
import java.util.Scanner;

/*
En esta clase esta el metodo main, donde se probara el programa.
 */
public class Prueba {
    private static Scanner sc = new Scanner(System.in);

    public static void imprimirMenu() {
        System.out.println("Ingresa el numero de la opcion que deseas elegir");
        System.out.println("1. Registrar trabajadores \n " +
                "2. Consultar trabajadores \n" +
                "3. Registrar construcciones \n" +
                "4. Registrar trabajadores de construcciones \n" +
                "5. Registrar materiales \n" +
                "6. Consultar materiales \n" +
                "7. Consultar construcciones pendientes \n" +
                "8. Registrar supervisor \n" +
                "9. Salir");
    }

    public static void menuOpcion2() {
        System.out.println("Ingresa el numero de la opcion que deseas elegir \n" +
                "1. Consultar Albañiles \n" +
                "2. Consultar Albaniles maestros \n" +
                "3. Consultar Arquitectos \n" +
                "4. Consultar Ingenieros civiles");
    }

    public static void menuOpcion1() {
        System.out.println("Ingresa el numero de la opcion que deseas elegir \n" +
                "1. Registrar Albañiles \n" +
                "2. Registrar Albaniles maestros \n" +
                "3. Registrar Arquitectos \n" +
                "4. Registrar Ingenieros civiles");
    }

    /*
    Este metodo es para llegar a los subcasos del caso 1.
     */
    public static void case1(RegistrosYAltas registrosYAltas) {
        menuOpcion1();
        int opcion = sc.nextInt();
        switch (opcion) {
            case 1:
                registrosYAltas.registrarAlbanil();
                break;
            case 2:
                registrosYAltas.registraAlbanilMaestro();
                break;
            case 3:
                registrosYAltas.registrarArquitecto();
                break;
            case 4:
                registrosYAltas.registrarIngCivil();
                break;
            default:
                System.out.println("Numero incorrecto");
        }
    }

    /*
    Este metodo es para llegar a los subcasos del caso 2.
    */
    public static void case2(Consultas consulta){
        menuOpcion2();
        int opcion = sc.nextInt();
        switch (opcion){
            case 1:
                consulta.consultarAlbanil();
                break;
            case 2:
                consulta.consultarAlbanilMaestro();
                break;
            case 3:
                consulta.consultarArquitecto();
                break;
            case 4:
                consulta.consultarIngenieros();
                break;
            default:
                System.out.println("Numero incorrecto");
        }
    }

    /*
    En este metodo es donde se eligen los trabajadores para las construcciones, primero pidiendo la construccion y depsues al trabajdor.
     */
    public static void caso4(RegistrosYAltas registros){
        ArrayList<Construccion> construccions =  RegistrosYAltas.getConstruccions();
        System.out.println("Elige la construccion a la que le deseas agregar trabajadores.");
        Construccion construccion =  construccions.get(registros.elegirConstruccion());
        System.out.println("Elige el trabajador que deseas agregar");
        ArrayList<Trabajador> trabajadors = RegistrosYAltas.getTrabajadors();
        Trabajador trabajador = trabajadors.get(registros.elegirTrabajador());
        construccion.agregarTrabajador(trabajador);


    }
    /*
    Metodo main donde todas las opciones posibles estaran a dispocision del usuario en un switch.
    */
    public static void main(String[] args) {
        RegistrosYAltas registros = new RegistrosYAltas();
        Consultas consultas = new Consultas();
        int opcion;
        do{
           imprimirMenu();
           opcion = sc.nextInt();
           switch (opcion){
               case 1:
                   case1(registros);
                   break;
               case 2:
                   case2(consultas);
                   break;
               case 3:
                   registros.registrarConstruccion();
                   break;
               case 4:
                   caso4(registros);
                   break;
               case 5:
                   registros.registrarMateriales();
                   break;
               case 6:
                   consultas.consultarMateriales();
                   break;
               case 7:
                   consultas.consultarConstruccionesPendientes();
                   break;
               case 8:
                   registros.registrarSupervisor();

           }

        }while (opcion != 9 );
    }
}
