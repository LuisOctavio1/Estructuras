package entradasalida;

public class SalidaPorDefecto {
    public static void consola(String cadenaSalida){
        System.out.print(cadenaSalida);
    }
}
