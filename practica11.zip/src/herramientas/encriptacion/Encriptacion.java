package herramientas.encriptacion;

import entradasalida.archivos.ArchivoTexto;
import estructuraslineales.ListaEstatica;
import estructuraslineales.PilaEstatica;
import java.util.Random;

public class Encriptacion {

    /**
     * Metodo que encripta cada linea del archivo y luego lo guarda en un archivo aparte llamado tectoEncriptado
     * @param ruta La ruta del archivo txt que queremos encriptar
     */
    public static void encriptarArchivo(String ruta){
        ListaEstatica archivo = ArchivoTexto.leer(ruta);
        for(int indice =0; indice < archivo.numeroElementos(); indice++){
            String linea = (String) archivo.obtener(indice);
            ListaEstatica lista = elegirIndices(linea);
            String lineaEncriptada = encriptarLinea(linea,lista);
            archivo.cambiar(indice,lineaEncriptada);
        }
        ArchivoTexto.escribir(archivo,"estructuras/src/textoEncriptado.txt");
    }

    /**
     * Metodo que elige los indices donde se pondran los carecteres especiales y se invertira el texto
     * @param linea La linea de donde se eligiran los indices
     * @return lista con las pilas que tienen los indices
     */
    private static ListaEstatica elegirIndices(String linea){
        Random r = new Random();
        int cantidad = r.nextInt(linea.length()) + 1;
        PilaEstatica posiciones = new PilaEstatica(cantidad);
        PilaEstatica anchos = new PilaEstatica(cantidad);
        int anterior = linea.length()-2;
        for(int indice =0; indice < cantidad; indice++){
            if(anterior >1 && !posiciones.lleno()){
                int posicion = r.nextInt(1,anterior);
                int ancho = r.nextInt(0, posicion);
                posiciones.poner(posicion);
                anchos.poner(ancho);
                anterior = ancho-1;
            }
        }
        ListaEstatica listas = new ListaEstatica(2);
        listas.agregar(posiciones);
        listas.agregar(anchos);
        return listas;
    }

    /**
     * Metodo que encripta la lina dada.
     * @param linea La linea que queremos encriptar.
     * @param indices La lista con las pilas que contienen los indices.
     * @return La linea encriptada
     */
    private static String encriptarLinea(String linea, ListaEstatica indices){
        String nuevaLinea = "";
        PilaEstatica posiciones = (PilaEstatica) indices.obtener(0);
        PilaEstatica anchos = (PilaEstatica) indices.obtener(1);
        for(int posicion = 0; posicion < linea.length(); posicion++){
            if(!posiciones.vacio()){
                if(posicion == (int)anchos.verUltimo()){
                    posicion = (int)posiciones.verUltimo();
                    nuevaLinea =nuevaLinea+ "Æ" + voltearParteCadena(linea,(int)anchos.quitar(),(int)posiciones.quitar())+"Æ" ;

                }else{
                        nuevaLinea = nuevaLinea + linea.charAt(posicion);
                }
            }else{
                nuevaLinea =  nuevaLinea+ linea.charAt(posicion) ;
            }

        }
        return nuevaLinea;
    }

    /**
     * Metodo que voltea la cadena entre el inicio y el fin.
     * @param cadena La liena de donde se volteara una parte.
     * @param inicio El inicio de donde se colteara.
     * @param fin El fin de la inversion de la parte.
     * @return
     */
    private static String voltearParteCadena(String cadena, int inicio, int fin){
        String inversa = "";
        for(int indice = fin; indice >= inicio; indice--){
            inversa = inversa + cadena.charAt(indice);
        }
        return inversa;
    }
}
