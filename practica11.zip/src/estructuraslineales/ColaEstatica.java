package estructuraslineales;

import entradasalida.SalidaPorDefecto;

public class ColaEstatica implements LoteAlmacenamiento {
    protected Object datos[];
    protected int primero;
    protected int ultimo;
    protected int MAXIMO;

    public ColaEstatica(int maximo){
        MAXIMO=maximo;
        datos=new Object[MAXIMO];
        primero=-1;
        ultimo=-1;
    }

    @Override
    public boolean vacio(){
        if(primero==-1){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public boolean lleno(){
        if((primero==0 && ultimo== (MAXIMO -1)) || primero== (ultimo+1)){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public boolean poner(Object valor){
        return false;
    }

    @Override
    public Object quitar(){
        return null;
    }

    @Override
    public void imprimir(){
        if(vacio()==false){ //hay algo, a)
            if(primero<=ultimo){ //b, comportamiento lineal
                for(int indice=primero;indice<=ultimo;indice++){
                    SalidaPorDefecto.consola(""+datos[indice]+ " ");
                }
            }else{ //c, comportamiento circular
                for(int indice=primero;indice<=(MAXIMO -1);indice++){
                    SalidaPorDefecto.consola(""+datos[indice]+ " ");
                }
                for(int indice=0;indice<=ultimo;indice++){
                    SalidaPorDefecto.consola(""+datos[indice]+ " ");
                }
            }
        }
    }

    @Override
    public Object verUltimo(){
        if(vacio()==false){
            return datos[ultimo];
        }else{
            return null;
        }
    }

    public Object verPrimero(){
        if(vacio()==false){
            return datos[primero];
        }else{
            return null;
        }
    }
}
