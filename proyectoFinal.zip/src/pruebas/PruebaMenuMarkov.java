package pruebas;

import menus.markov.MenuMarkovPrincipal;

public class PruebaMenuMarkov {
    public static void main(String[] args) {
        MenuMarkovPrincipal menu = new MenuMarkovPrincipal();
    }
}
