package menus;

public class MenuMorkov {
}
