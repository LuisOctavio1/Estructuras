package menus;

import javax.swing.*;

public class MenuMar {

    private JPanel panel1;
    private JButton aProbabilidadDeQueButton;
}
