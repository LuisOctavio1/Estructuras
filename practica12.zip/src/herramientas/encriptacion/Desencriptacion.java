package herramientas.encriptacion;

import entradasalida.archivos.ArchivoTexto;
import estructuraslineales.ListaEstatica;
import estructuraslineales.PilaEstatica;

import java.util.Random;

public class Desencriptacion {
    /**
     * Metodo que desencripta un archivo dado.
     * @param ruta La ruta del archivo encriptado.
     */
    public static void desencriptar(String ruta){
        ListaEstatica archivo = ArchivoTexto.leer(ruta);
        for(int indice =0; indice < archivo.numeroElementos(); indice++){
            String linea = (String) archivo.obtener(indice);
            String lineaDesencriptada = desencriptarLinea(linea);
            archivo.cambiar(indice,lineaDesencriptada);
        }
        ArchivoTexto.escribir(archivo,"estructuras/src/textoDesencriptado.txt");
    }

    /**
     * Metodo que desencripta una linea en especifoca.
     * @param linea La linea que se quiere desencriptar.
     * @return
     */
    private static String desencriptarLinea(String linea){
        String nuevaLinea = "";
        for(int indice =0; indice < linea.length(); indice++){
            if(linea.charAt(indice) == 'Æ'){
                PilaEstatica pila  = new PilaEstatica(linea.length());
                for(int posicion = indice+1; posicion < linea.length(); posicion++){
                    if(linea.charAt(posicion) !='Æ'){

                        pila.poner(linea.charAt(posicion));
                    }else{
                        indice = posicion;
                        break;
                    }
                }
                String palabraArreglada = voltearParteCadena(pila,linea);
                nuevaLinea = nuevaLinea + palabraArreglada;
            }else{
                nuevaLinea = nuevaLinea + linea.charAt(indice);
            }
        }
        return nuevaLinea;
    }


    /**
     * Metodo que voltea una parte de una cadena donde las latras a voltear estan en la pila.
     * @param pila La pila que contiene las letras a voltear.
     * @param linea La linea de donde provienen los caracteres.
     * @return La palabra obtenida de la pila.
     */
    private static String voltearParteCadena(PilaEstatica pila,String linea){
        String inversa = "";
        for(int indice = 0; indice < linea.length(); indice--){
            if(!pila.vacio()){
                inversa = inversa + pila.quitar();
            }else{

                return inversa;
            }
        }
        return inversa;
    }
}
