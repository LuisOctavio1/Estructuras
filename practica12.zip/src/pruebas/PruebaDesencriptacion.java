package pruebas;

import herramientas.encriptacion.Desencriptacion;

public class PruebaDesencriptacion {
    public static void main(String[] args) {
        Desencriptacion.desencriptar("estructuras/src/textoEncriptado.txt");
    }
}
