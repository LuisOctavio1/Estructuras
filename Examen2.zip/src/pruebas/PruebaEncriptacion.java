package pruebas;

public class PruebaEncriptacion {


    public static void main(String[] args) {
        //Encriptacion.encriptarArchivo("estructuras/src/texto.txt");

    }
}
