package pruebas;

import estructurasnolineales.ArbolBinario;

public class PruebaArbolesExpresiones {
    public static void main(String[] args) {
        ArbolBinario arbol = new ArbolBinario();
        arbol.generarArbol();
    }

}
