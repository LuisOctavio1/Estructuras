package estructurasnolineales;

import entradasalida.EntradaPorDefecto;
import entradasalida.SalidaPorDefecto;
import estructuraslineales.auxiliares.NodoDoble;

public class ArbolBinario {
    protected NodoDoble raiz;

    public ArbolBinario(){
        raiz=null;
    }

    public boolean generarArbol(){
        SalidaPorDefecto.consola("Indica la raíz: ");
        String contenidoNodo= EntradaPorDefecto.consolaCadenas();
        NodoDoble nuevoNodo=new NodoDoble(contenidoNodo);
        if(nuevoNodo!=null){ //hay espacio de memoria
            raiz=nuevoNodo;
            generarArbol(raiz);
            return true;
        }else{ //no hay espacio de memoria
            return false;
        }
    }

    private void generarArbol(NodoDoble subRaiz){ //Por cada Subraiz
        //Agregar hijo izquierdo
        SalidaPorDefecto.consola("¿El nodo "+ subRaiz.getContenido()+ " tiene hijo izquierdo ? ");
        String respuestaPreguntaHijoIzq=EntradaPorDefecto.consolaCadenas();
        if(respuestaPreguntaHijoIzq.equalsIgnoreCase("s")){ //si quiuere agregar un hijo izquierdo
            SalidaPorDefecto.consola("Indica el dato del hijo izquierdo: ");
            String contenidoNodoIzquierdo=EntradaPorDefecto.consolaCadenas();
            NodoDoble nuevoNodoIzquierdo=new NodoDoble(contenidoNodoIzquierdo);
            if(nuevoNodoIzquierdo!=null){ //si hay espacio
                subRaiz.setNodoIzq(nuevoNodoIzquierdo); //ligamos la subraiz a este hijo nuevo
                //llamada recursiva para ver si a este nodo izquierdo le corresponden tener hijo también
                generarArbol(subRaiz.getNodoIzq());
            }
        }//si no quiere tener hijo izquierdo, no hacemos nada, es decir, caso base

        //Agregar hijo derecho
        SalidaPorDefecto.consola("¿El nodo "+ subRaiz.getContenido()+ " tiene hijo derecho ? ");
        String respuestaPreguntaHijoDer=EntradaPorDefecto.consolaCadenas();
        if(respuestaPreguntaHijoDer.equalsIgnoreCase("s")){ //si quiuere agregar un hijo derecho
            SalidaPorDefecto.consola("Indica el dato del hijo derecho: ");
            String contenidoNodoDerecho=EntradaPorDefecto.consolaCadenas();
            NodoDoble nuevoNodoDerecho=new NodoDoble(contenidoNodoDerecho);
            if(nuevoNodoDerecho!=null){ //si hay espacio
                subRaiz.setNodoDer(nuevoNodoDerecho); //ligamos la subraiz a este hijo nuevo
                //llamada recursiva para ver si a este nodo derecho le corresponden tener hijo también
                generarArbol(subRaiz.getNodoDer());
            }
        }//si no quiere tener hijo derecho, no hacemos nada, es decir, caso base
    }

    public void inorden(){
        inorden(raiz);
    }

    private void inorden(NodoDoble subRaiz){
        //IRD
        if(subRaiz!=null) {
            inorden(subRaiz.getNodoIzq());
            SalidaPorDefecto.consola(subRaiz.getContenido() + " ");
            inorden(subRaiz.getNodoDer());
        } //en el else el caso base, donde n ose hace nada
    }

    public void preorden(){
        preorden(raiz);
    }

    private void preorden(NodoDoble subRaiz){
        //RID
        if(subRaiz!=null) {
            SalidaPorDefecto.consola(subRaiz.getContenido() + " ");
            preorden(subRaiz.getNodoIzq());
            preorden(subRaiz.getNodoDer());
        } //en el else el caso base, donde n ose hace nada
    }

    public void postorden(){
        postorden(raiz);
    }

    private void postorden(NodoDoble subRaiz){
        //IDR
        if(subRaiz!=null) {
            postorden(subRaiz.getNodoIzq());
            postorden(subRaiz.getNodoDer());
            SalidaPorDefecto.consola(subRaiz.getContenido() + " ");
        } //en el else el caso base, donde n ose hace nada
    }


}